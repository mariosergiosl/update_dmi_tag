# -*- coding: utf-8 -*-

# =======================================================================
#
# FILE: summary.py
#
# DESCRIPTION: Geracao da tabela de resumo final (monta_tabela_resumo):
#              tabela detalhada (1 linha por host, com colunas IP,
#              Hostname, Fabricante, Modelo, Fab.BIOS, Versao BIOS,
#              SMBIOS, WSMT, tags, BEM conf/usado, Resultado, BBconfig
#              e MAC) e sumario agregado (agrupado por Versao BIOS +
#              flag -w + Resultado).
#
# AUTHOR: Mario Luz mario.luz@suse.com
# COMPANY: SUSE
# VERSION: 2.1.9
# CREATED: 2026-06-12
# REVISION: 2026-07-07 - v2.1.9 - atualizacao de numero de versao para
#                        consistencia com o restante do pacote; sem
#                        mudanca funcional neste arquivo.
# REVISION: 2026-06-12 - v2.1.0 - extraido de update_dmi_tag.py na
#                        modularizacao em pacote. Conteudo identico,
# REVISION: 2026-06-15 - v2.1.1 - adiciona coluna MAC.
# REVISION: 2026-06-15 - v2.1.2 - remove coluna Backup; BBconfig exibe
#                        DRY-RUN; corrige coluna fantasma no sumario.
# REVISION: 2026-06-15 - v2.1.3 - colunas Fabricante, Modelo, Fab.BIOS
#                        e Versao BIOS separadas.
# REVISION: 2026-06-15 - v2.1.4 - adiciona coluna Teste Escrita.
# REVISION: 2026-06-15 - v2.1.5 - adiciona SEM-SUDO a _DESCRICOES_RESULTADO.
# REVISION: 2026-06-16 - v2.1.6 - substitui bloco de contadores por
#                        linhas individuais explicitas para cada status
#                        (OK-amidelnx, OK-amibios, DRY-RUN, FALHOU,
#                        SEM-SUDO, PENDENTE, INVALIDO, INACESSIVEL).
#                        Todas as linhas sempre exibidas mesmo com valor
#                        zero: explicito e melhor que implicito.
#
# =======================================================================

import sys


def _normaliza_fabricante(board_vendor):
    """
    NAME: _normaliza_fabricante
    DESCRIPTION: Normaliza nomes de fabricante de placa-mae verbosos
                 para liberar espaco na tabela detalhada. Apenas o
                 caso observado no parque:
                   "Daten Tecnologia Ltda" -> "Daten"
                   "Gigabyte Technology Co., Ltd." -> "Gigabyte"
                   "Positivo Tecnologia" -> "Positivo"
                 Demais fabricantes permanecem inalterados.
    PARAMETER: board_vendor - string do fabricante (registro["board_vendor"])
    RETURNS: str -- fabricante normalizado
    """
    if not board_vendor:
        return board_vendor
    mapeamentos = (
        ("Daten Tecnologia Ltda", "Daten"),
        ("Gigabyte Technology Co., Ltd.", "Gigabyte"),
        ("Positivo Tecnologia", "Positivo"),
        ("PERTOSA", "PERTOSA"),
    )
    for origem, destino in mapeamentos:
        if board_vendor.startswith(origem):
            return destino
    return board_vendor


def _normaliza_bios_vendor(bios_vendor):
    """
    NAME: _normaliza_bios_vendor
    DESCRIPTION: Abrevia nomes de fabricante de BIOS conhecidos para
                 exibicao na coluna Fab.BIOS da tabela detalhada.
                 Fabricantes conhecidos sao mapeados para abreviatura.
                 Valores desconhecidos aparecem truncados como vieram
                 (sem perder informacao inesperadamente).
    PARAMETER: bios_vendor - string do fabricante da BIOS
                             (registro["bios_vendor"])
    RETURNS: str -- fabricante abreviado ou primeiros 10 chars se
             desconhecido
    """
    if not bios_vendor or bios_vendor == "N/D":
        return bios_vendor
    mapeamentos = (
        ("American Megatrends", "AMI"),
        ("Phoenix Technologies", "Phoenix"),
        ("Award Software", "Award"),
        ("Insyde Software", "Insyde"),
        ("Positivo", "Positivo"),
        ("Hewlett-Packard", "HP"),
        ("Dell Inc.", "Dell"),
        ("Lenovo", "Lenovo"),
    )
    for origem, destino in mapeamentos:
        if bios_vendor.startswith(origem):
            return destino
    # Valor desconhecido: retorna os primeiros 10 chars para nao truncar
    # silenciosamente sem aviso, mas caber na coluna
    return bios_vendor[:10]


# Mapeamento de resultado/status para descricao em linguagem natural,
# usado no sumario agregado. Chaves sao comparadas por prefixo (ex:
# "FALHOU" cobre "FALHOU-todos"; "INACESSIVEL" e exato).
_DESCRICOES_RESULTADO = (
    ("OK-amidelnx", "Sucesso. Gravacao confirmada via amidelnx_64 (Mecanismo 1)."),
    ("OK-amibios",  "Sucesso. Gravacao confirmada via amibios_dmi/sysfs (Mecanismo 2, fallback)."),
    ("DRY-RUN",     "Leitura realizada com sucesso (Simulacao). Nenhuma gravacao executada."),
    ("FALHOU",      "Bloqueio no firmware: ambos os mecanismos rejeitaram a gravacao."),
    ("PENDENTE",    "BEM_NUMERO ausente no BBconfig.conf. Aguardando provisionamento."),
    ("INVALIDO",    "BEM_NUMERO com formato invalido (esperado 13 ou 14 digitos)."),
    ("SEM-SUDO",    "Usuario sem privilegio sudo no host (ou --sudo-pass incorreto/ausente). Escrita nao tentada."),
    ("INACESSIVEL", "Host nao respondeu via SSH (timeout, desligado, ou bootstrap de chave falhou)."),
)


def _descricao_resultado(resultado):
    """
    NAME: _descricao_resultado
    DESCRIPTION: Traduz o codigo de resultado/status de um host para uma
                 descricao em linguagem natural, usada no sumario
                 agregado. Faz match por prefixo (primeira correspon-
                 dencia na ordem de _DESCRICOES_RESULTADO). Se nenhum
                 prefixo bater, retorna o proprio resultado como
                 descricao (fallback seguro para status desconhecidos
                 introduzidos no futuro).
    PARAMETER: resultado - string de resultado (ex: "OK-amidelnx",
               "FALHOU-todos", "INACESSIVEL")
    RETURNS: str -- descricao em linguagem natural
    """
    resultado = str(resultado or "")
    for prefixo, descricao in _DESCRICOES_RESULTADO:
        if resultado.startswith(prefixo):
            return descricao
    return resultado


def monta_tabela_resumo(registros, caminho_log_local, verbose, suprime_tela,
                        write_ativo=False):
    """
    NAME: monta_tabela_resumo
    DESCRIPTION: Gera duas tabelas no log final:
                   1. TABELA DETALHADA -- uma linha por host, com
                      colunas IP, Hostname, Placa (normalizada), BIOS,
                      SMBIOS, WSMT, Tag Antes, BEM conf, BEM usado,
                      Tag Depois, Resultado, BBconfig (status da
                      sincronizacao do BBconfig.conf) e Backup (nome do
                      arquivo de backup gerado, se houve).
                   2. SUMARIO AGREGADO -- agrupa os registros por
                      (BIOS, flag -w, Resultado), mostrando a contagem
                      de cada combinacao e uma descricao em linguagem
                      natural do que aquele resultado significa
                      (_descricao_resultado). Permite avaliar o
                      resultado de uma execucao em massa rapidamente,
                      sem precisar ler linha a linha.
                 Ambas as tabelas sao escritas no log local (se
                 configurado) e no stdout (se nao suprimido).
    PARAMETER: registros         - lista de dicts retornados por
                                    processa_host_remoto
               caminho_log_local - log consolidado local
               verbose           - modo verbose
               suprime_tela      - suprime stdout
               write_ativo       - bool, valor de args.write desta
                                    execucao (usado na coluna -w do
                                    sumario agregado)
    """
    def _escreve(linha):
        if caminho_log_local:
            try:
                with open(caminho_log_local, "a", encoding="utf-8") as f:
                    f.write(linha + "\n")
            except Exception:
                pass
        if not suprime_tela:
            sys.stdout.write(linha + "\n")

    def _cel(valor, largura):
        s = str(valor if valor not in (None, "") else "N/D")
        return s[:largura].ljust(largura)

    def _cel_raw(valor, largura):
        """Como _cel, mas string vazia permanece vazia (nao vira N/D).
        Usado para colunas onde 'vazio' e um valor valido, como Backup
        (nenhum backup foi gerado)."""
        s = str(valor) if valor is not None else ""
        return s[:largura].ljust(largura)

    # =====================================================================
    # 1. TABELA DETALHADA
    # =====================================================================
    C = {
        "ip":             15,
        "hostname":       13,
        "board_vendor":   10,
        "board_name":     20,
        "bios_vendor":     8,
        "bios_version":   14,
        "smbios":          7,
        "wsmt":            7,
        "tag_antes":      15,
        "bem_conf":       14,
        "bem_usado":      14,
        "tag_depois":     15,
        "resultado":      13,
        "teste_escrita":  13,
        "bbconfig_sync":  17,
        "mac":            52,
    }
    CABECALHOS = [
        "IP", "Hostname", "Fabricante", "Modelo",
        "Fab.BIOS", "Versao BIOS", "SMBIOS", "WSMT",
        "Tag Antes", "BEM conf", "BEM usado", "Tag Depois",
        "Resultado", "Teste Escrita", "BBconfig", "MAC",
    ]

    div = "+-" + "-+-".join("-" * (v + 2) for v in C.values()) + "-+"
    cab = "| " + " | ".join(_cel(h, w) for h, w in zip(CABECALHOS, C.values())) + " |"
    sep = "=" * len(cab)

    _escreve("")
    _escreve(sep)
    _escreve("RESUMO DETALHADO -- {} equipamento(s) processado(s)".format(len(registros)))
    _escreve(sep)
    _escreve(div)
    _escreve(cab)
    _escreve(div)

    for r in registros:
        linha_valores = dict(r)
        linha_valores["board_vendor"] = _normaliza_fabricante(
            r.get("board_vendor", "N/D"))
        linha_valores["bios_vendor"]  = _normaliza_bios_vendor(
            r.get("bios_vendor", "N/D"))
        # bbconfig_sync: substitui N/A por DRY-RUN quando resultado for DRY-RUN
        if (str(r.get("resultado", "")) == "DRY-RUN"
                and linha_valores.get("bbconfig_sync") == "N/A"):
            linha_valores["bbconfig_sync"] = "DRY-RUN"
        partes = [_cel(linha_valores.get(k, "N/D"), w) for k, w in C.items()]
        _escreve("| " + " | ".join(partes) + " |")

    _escreve(div)
    _escreve("")

    # =====================================================================
    # 2. SUMARIO AGREGADO
    # =====================================================================
    # Agrupa por (BIOS, flag -w, Resultado). A ordem de insercao do dict
    # e preservada (Python 3.7+), mantendo a ordem em que os grupos
    # aparecem na execucao.
    grupos = {}
    flag_w = "-w" if write_ativo else ""
    for r in registros:
        bios = r.get("bios_version", "N/D") or "N/D"
        resultado = r.get("resultado", "N/D") or "N/D"
        chave = (bios, flag_w, resultado)
        grupos[chave] = grupos.get(chave, 0) + 1

    CS = {
        "bios":       15,
        "flag_w":      5,
        "resultado":  14,
        "qtd":         5,
        "observacao": 80,
    }
    CABECALHOS_S = ["BIOS", "-w", "Status", "Qtd", "Observacao"]
    div_s = "+-" + "-+-".join("-" * (v + 2) for v in CS.values()) + "-+"
    cab_s = "| " + " | ".join(_cel(h, w) for h, w in zip(CABECALHOS_S, CS.values())) + " |"
    sep_s = "=" * len(cab_s)

    _escreve(sep_s)
    _escreve("SUMARIO AGREGADO")
    _escreve(sep_s)
    _escreve(div_s)
    _escreve(cab_s)
    _escreve(div_s)

    for (bios, fw, resultado), qtd in grupos.items():
        observacao = _descricao_resultado(resultado)
        valores = {
            "bios": bios, "flag_w": fw, "resultado": resultado,
            "qtd": qtd, "observacao": observacao,
        }
        partes = [_cel(valores[k], w) for k, w in CS.items()]
        _escreve("| " + " | ".join(partes) + " |")

    _escreve(div_s)
    _escreve("")

    # =====================================================================
    # CONTADORES INDIVIDUAIS POR STATUS
    # Todas as linhas sao sempre exibidas (mesmo com valor 0) para que o
    # operador possa interpretar o resultado sem ambiguidade. Explicito
    # e sempre melhor que implicito.
    # =====================================================================
    total = len(registros)

    # Gravacoes bem-sucedidas (qualquer mecanismo)
    ok_amidelnx = sum(1 for r in registros if r.get("resultado") == "OK-amidelnx")
    ok_amibios  = sum(1 for r in registros if r.get("resultado") == "OK-amibios")
    ok_total    = ok_amidelnx + ok_amibios

    # Simulacao sem gravacao
    dryrun = sum(1 for r in registros if r.get("resultado") == "DRY-RUN")

    # Falha na cascata de mecanismos (escrita foi tentada e rejeitada pela BIOS)
    falhou = sum(1 for r in registros if str(r.get("resultado","")).startswith("FALHOU"))

    # Sem privilegio sudo (escrita nao foi tentada)
    sem_sudo = sum(1 for r in registros if r.get("resultado") == "SEM-SUDO")

    # BEM_NUMERO ausente no arquivo de configuracao
    pendente = sum(1 for r in registros if r.get("resultado") == "PENDENTE")

    # BEM_NUMERO com formato invalido
    invalido = sum(1 for r in registros if r.get("resultado") == "INVALIDO")

    # Host inacessivel via SSH
    inacessivel = sum(1 for r in registros if r.get("resultado") == "INACESSIVEL")

    # Qualquer outro status nao mapeado acima
    outros = total - ok_total - dryrun - falhou - sem_sudo - pendente - invalido - inacessivel

    _escreve("  Gravacao OK (amidelnx_64)  : {:3d}  -- escrita confirmada via Mecanismo 1".format(ok_amidelnx))
    _escreve("  Gravacao OK (amibios_dmi)  : {:3d}  -- escrita confirmada via Mecanismo 2 (fallback)".format(ok_amibios))
    _escreve("  Simulacao (DRY-RUN)        : {:3d}  -- apenas leitura, nenhuma gravacao executada".format(dryrun))
    _escreve("  Falha na escrita (FALHOU)  : {:3d}  -- cascata tentada, BIOS rejeitou ambos os mecanismos".format(falhou))
    _escreve("  Sem privilegio (SEM-SUDO)  : {:3d}  -- usuario sem sudo ou --sudo-pass incorreto/ausente".format(sem_sudo))
    _escreve("  BEM pendente (PENDENTE)    : {:3d}  -- BEM_NUMERO ausente no BBconfig.conf do host".format(pendente))
    _escreve("  BEM invalido (INVALIDO)    : {:3d}  -- BEM_NUMERO com formato invalido (esperado 13 ou 14 digitos)".format(invalido))
    _escreve("  Inacessivel (INACESSIVEL)  : {:3d}  -- host nao respondeu via SSH (desligado, rede, bootstrap)".format(inacessivel))
    if outros > 0:
        _escreve("  Outros (status desconhecido): {:3d}  -- status nao mapeado acima".format(outros))
    _escreve("  " + "-" * 60)
    _escreve("  Total processado           : {:3d}".format(total))
    _escreve("")


